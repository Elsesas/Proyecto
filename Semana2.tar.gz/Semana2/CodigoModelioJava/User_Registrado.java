import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("59bf06f0-1a4a-4e78-942d-2fb6c2dd3890")
public class User_Registrado extends Usuario {
    @objid ("fb768913-12b6-435e-8ba4-d7ece034eb19")
    public String Fecha_Alta;

    @objid ("b139522f-3a96-4ea9-9559-1117d7f82161")
    public String Numero_Prestamos;

}
