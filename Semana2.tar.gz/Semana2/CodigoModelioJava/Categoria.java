import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("23db1511-5eeb-4c6e-8386-9880fcde234c")
public class Categoria {
    @objid ("44faa402-00cb-43bb-8906-38fddec0d9e6")
    public String Nombre_Categoria;

    @objid ("f968ceea-f51e-4319-9a4f-d618ac5f7c91")
    public String Descripcion;

    @mdl.prop
    @objid ("79badd4d-8452-43a3-9113-d8e88abe8a20")
    private Documentos documentos;

    @mdl.propgetter
    public Documentos getDocumentos() {
        // Automatically generated method. Please do not modify this code.
        return this.documentos;
    }

    @mdl.propsetter
    public void setDocumentos(final Documentos value) {
        // Automatically generated method. Please do not modify this code.
        this.documentos = value;
    }

}
