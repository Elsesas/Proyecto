import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("80efbbc0-7457-4495-adf9-2d7a8872f27f")
public class Digital extends Documentos {
    @objid ("14915d9e-352a-479a-bef6-62d8121c7897")
    public int Archivo_Digital;

}
