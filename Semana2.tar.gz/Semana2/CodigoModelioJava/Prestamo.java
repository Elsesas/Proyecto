import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d18bd379-5182-4a76-b721-737fdb42f1e2")
public class Prestamo {
    @objid ("f49beb2a-31a7-4583-93e0-784b54555846")
    public String Fecha_Entrega;

    @objid ("ab4210d0-fe9a-4439-a118-665111187c60")
    public String Fecha_Hora_Devolucion;

    @objid ("46d98f1f-2d06-4a48-8244-6e72c3f5ec23")
    public String ID;

}
