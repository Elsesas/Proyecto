import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b24317c1-817e-43ad-864a-c8a428441cd6")
public class Fisica extends Documentos {
    @objid ("e3d5b613-ee75-4253-9ab4-a43b1a99a727")
    public int Numero_Resguardo;

}
