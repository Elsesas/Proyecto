import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5c79a31d-aa57-466a-a40a-738bb0a77ae0")
public class Usuario {
    @objid ("ec0e914c-48e1-47aa-b37b-fe8d0fee3212")
    public String Nif;

    @objid ("085276fb-18b8-4b30-8d7c-125ec9b0498e")
    public String Nombre;

    @objid ("4bf12159-7f2a-4555-aced-5d3433770fbe")
    public String Apellidos;

    @objid ("f417cac7-45d0-4dc6-b312-d8d646c33b96")
    public String Telefono;

}
