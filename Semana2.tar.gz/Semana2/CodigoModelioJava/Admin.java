import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b30bd98a-0c8e-4339-b1e7-625bafee1ecb")
public class Admin extends Usuario {
    @objid ("6033f234-2a7b-4784-a590-081b414aef51")
    public String Horario;

    @objid ("dc277bfa-6e66-4499-9f4b-b12b6796e03a")
    public Admin admin;

    @objid ("09861e4e-927b-41c8-8dc7-5e94ba3c1f9d")
    public List<Admin>  = new ArrayList<Admin> ();

}
