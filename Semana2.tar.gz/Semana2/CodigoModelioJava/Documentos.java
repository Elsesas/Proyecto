import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0f3ee366-c005-4e7d-8f74-ce55ac74bd3c")
public class Documentos {
    @objid ("55fe2f97-b6eb-4724-b654-d8177040f666")
    public String Fecha_Entrega;

    @objid ("a2ebc2d8-bb2a-44d5-ac37-bd5e604548ce")
    public String Fecha_Hora_Devolucion;

    @objid ("64057be8-b347-4614-9bd5-d75aff71f151")
    public List<Categoria>  = new ArrayList<Categoria> ();

}
