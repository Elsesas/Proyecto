-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 15-04-2024 a las 20:15:26
-- Versión del servidor: 5.7.22-0ubuntu0.17.10.1
-- Versión de PHP: 7.1.17-0ubuntu0.17.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ProyectoProg`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Administrador`
--

CREATE TABLE `Administrador` (
  `Horario` date NOT NULL,
  `Usuario_NIF` varchar(10) NOT NULL,
  `Administrador_Usuario_NIF` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Categoria`
--

CREATE TABLE `Categoria` (
  `Codigo_Categoria` int(11) NOT NULL,
  `Nombre` varchar(45) DEFAULT NULL,
  `Descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Digital`
--

CREATE TABLE `Digital` (
  `Archivo_Digital` int(11) DEFAULT NULL,
  `Codigo_Documentos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Documentos`
--

CREATE TABLE `Documentos` (
  `Codigo_Documentos` int(11) NOT NULL,
  `Codigo_Categoria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Fisica`
--

CREATE TABLE `Fisica` (
  `Numero_Resguardo` int(11) DEFAULT NULL,
  `Codigo_Documentos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `PRESTAMO`
--

CREATE TABLE `PRESTAMO` (
  `Usuario_NIF` varchar(10) NOT NULL,
  `Codigo_Documentos` int(11) NOT NULL,
  `Fecha_Entrega` date DEFAULT NULL,
  `Fecha_Hora_Devolucion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Sustitución`
--

CREATE TABLE `Sustitución` (
  `Codigo_Documentos` int(11) NOT NULL,
  `Codigo_Documentos1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario`
--

CREATE TABLE `Usuario` (
  `NIF` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario_Registrado`
--

CREATE TABLE `Usuario_Registrado` (
  `Fecha_Alta` date NOT NULL,
  `Num_Prestamos` int(11) DEFAULT NULL,
  `Usuario_NIF` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Administrador`
--
ALTER TABLE `Administrador`
  ADD PRIMARY KEY (`Usuario_NIF`,`Administrador_Usuario_NIF`),
  ADD KEY `fk_Administrador_Administrador1_idx` (`Administrador_Usuario_NIF`);

--
-- Indices de la tabla `Categoria`
--
ALTER TABLE `Categoria`
  ADD PRIMARY KEY (`Codigo_Categoria`);

--
-- Indices de la tabla `Digital`
--
ALTER TABLE `Digital`
  ADD PRIMARY KEY (`Codigo_Documentos`),
  ADD KEY `fk_Digital_Documentos1_idx` (`Codigo_Documentos`);

--
-- Indices de la tabla `Documentos`
--
ALTER TABLE `Documentos`
  ADD PRIMARY KEY (`Codigo_Documentos`),
  ADD KEY `fk_Documentos_Categoria1_idx` (`Codigo_Categoria`);

--
-- Indices de la tabla `Fisica`
--
ALTER TABLE `Fisica`
  ADD PRIMARY KEY (`Codigo_Documentos`),
  ADD KEY `fk_Fisica_Documentos1_idx` (`Codigo_Documentos`);

--
-- Indices de la tabla `PRESTAMO`
--
ALTER TABLE `PRESTAMO`
  ADD PRIMARY KEY (`Codigo_Documentos`,`Usuario_NIF`),
  ADD KEY `fk_Usuario_has_Documentos_Documentos1_idx` (`Codigo_Documentos`),
  ADD KEY `fk_Usuario_has_Documentos_Usuario_idx` (`Usuario_NIF`);

--
-- Indices de la tabla `Sustitución`
--
ALTER TABLE `Sustitución`
  ADD PRIMARY KEY (`Codigo_Documentos`,`Codigo_Documentos1`),
  ADD KEY `fk_Documentos_has_Documentos_Documentos2_idx` (`Codigo_Documentos1`),
  ADD KEY `fk_Documentos_has_Documentos_Documentos1_idx` (`Codigo_Documentos`);

--
-- Indices de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`NIF`);

--
-- Indices de la tabla `Usuario_Registrado`
--
ALTER TABLE `Usuario_Registrado`
  ADD PRIMARY KEY (`Usuario_NIF`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Administrador`
--
ALTER TABLE `Administrador`
  ADD CONSTRAINT `fk_Administrador_Administrador1` FOREIGN KEY (`Administrador_Usuario_NIF`) REFERENCES `Administrador` (`Usuario_NIF`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Administrador_Usuario1` FOREIGN KEY (`Usuario_NIF`) REFERENCES `Usuario` (`NIF`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Digital`
--
ALTER TABLE `Digital`
  ADD CONSTRAINT `fk_Digital_Documentos1` FOREIGN KEY (`Codigo_Documentos`) REFERENCES `Documentos` (`Codigo_Documentos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Documentos`
--
ALTER TABLE `Documentos`
  ADD CONSTRAINT `fk_Documentos_Categoria1` FOREIGN KEY (`Codigo_Categoria`) REFERENCES `Categoria` (`Codigo_Categoria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Fisica`
--
ALTER TABLE `Fisica`
  ADD CONSTRAINT `fk_Fisica_Documentos1` FOREIGN KEY (`Codigo_Documentos`) REFERENCES `Documentos` (`Codigo_Documentos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `PRESTAMO`
--
ALTER TABLE `PRESTAMO`
  ADD CONSTRAINT `fk_Usuario_has_Documentos_Documentos1` FOREIGN KEY (`Codigo_Documentos`) REFERENCES `Documentos` (`Codigo_Documentos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Usuario_has_Documentos_Usuario` FOREIGN KEY (`Usuario_NIF`) REFERENCES `Usuario` (`NIF`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Sustitución`
--
ALTER TABLE `Sustitución`
  ADD CONSTRAINT `fk_Documentos_has_Documentos_Documentos1` FOREIGN KEY (`Codigo_Documentos`) REFERENCES `Documentos` (`Codigo_Documentos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Documentos_has_Documentos_Documentos2` FOREIGN KEY (`Codigo_Documentos1`) REFERENCES `Documentos` (`Codigo_Documentos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Usuario_Registrado`
--
ALTER TABLE `Usuario_Registrado`
  ADD CONSTRAINT `fk_Usuario_Registrado_Usuario1` FOREIGN KEY (`Usuario_NIF`) REFERENCES `Usuario` (`NIF`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
